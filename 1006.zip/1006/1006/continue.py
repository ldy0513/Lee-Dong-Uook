for i in range(10):
    if i == 5:continue
    print i
print "EOP"
