print "tell me your age?"
myage = int(raw_input())
if myage < 30:
    print "welcome to the club"
else:
    print "oh! no. here is not a travel night"
