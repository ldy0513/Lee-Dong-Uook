print "enter your name"
somebody = raw_input()
print "hi",somebody,"how are you today"
