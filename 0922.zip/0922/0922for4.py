for looper in range(0,100):
    print "hello"
