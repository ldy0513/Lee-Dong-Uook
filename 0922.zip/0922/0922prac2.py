#-*-coding:utf-8
print "구구단 몇단을 계산할까요?"
gu = int(raw_input())
print "구구단",gu,"단을 계산합니다"
for i in range (1,10) :
    print gu,"*",i,"=",gu*i
