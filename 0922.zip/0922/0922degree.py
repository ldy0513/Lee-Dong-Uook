# -*- coding: utf-8 -*-

print "본 프로그램은 섭씨를 화씨로로 변환해주는 프로그램입니다"
print "변환하고 싶은 섭씨  온도를 입력해 주세요: "
celcius = float(raw_input())
fah = ( (9.0/5.0) * celcius ) + 32
print "섭씨온도 :", celcius
print "화씨온도 :", fah
