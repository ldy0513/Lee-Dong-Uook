# -*- coding: cp949 -*-
a = 8
b = 5
If a == 8 and b ==4 
if a > 7 or b > 7
If not (a > 7)	
