for looper in ["kill","die","revive","ejection","aboard"]:
    print looper
